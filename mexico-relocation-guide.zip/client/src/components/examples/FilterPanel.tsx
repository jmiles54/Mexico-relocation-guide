import FilterPanel from '../FilterPanel';

export default function FilterPanelExample() {
  return (
    <div className="p-8 bg-background max-w-md">
      <FilterPanel />
    </div>
  );
}
